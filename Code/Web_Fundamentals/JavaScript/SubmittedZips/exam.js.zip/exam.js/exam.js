function remove(id) {
    let alert = document.getElementById('alert');
    alert.remove();
}

function popUp() {
    alert("Shopping Cart is empty!");
}

function changeImage(img){
    let change = document.getElementById('img');
    change.src = "./images/assets/succulents-2.jpg";
}