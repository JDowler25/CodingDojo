package com.jaydandowler.hoppers_receipt;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HoppersReceiptApplicationTests {

	@Test
	void contextLoads() {
	}

}
