public class FirstProgram {
   public static void main(String[] args) {
    System.out.println("My name is Jaydan");
    System.out.println("I am 26 years old");
    System.out.println("My hometown is Camarillo, Ca");
   } 
}