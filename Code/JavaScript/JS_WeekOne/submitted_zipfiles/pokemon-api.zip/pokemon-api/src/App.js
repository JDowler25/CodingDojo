import React from 'react';
import CallingApi from './components/pokemonapi';
import './App.css';

function App() {
  return (
    <div className="App">
      <CallingApi/>
      
    </div>
  );
}

export default App;
