import React, {useState} from "react";


const CallingApi = () => {
    const [allpokemon, setAllpokemon] = useState([])
    const fetchApi = () => {
        fetch("https://pokeapi.co/api/v2/pokemon?limit=1281&offset=0")
            .then(response => {
            // not the actual JSON response body but the entire HTTP response
            return response.json();
            }).then(response => {
            // we now run another promise to parse the HTTP response into usable JSON
            console.log(response);
            setAllpokemon(response.results);
            }).catch(err=>{
            console.log(err);
            });
    }
    return (
        <div>
            <button onClick={fetchApi}>Fetch Pokemon</button>
            {allpokemon.map((singlePokemon, index) => 
            <p key = {index}>{singlePokemon.name}</p>
            )}
        </div>
    )
}
export default CallingApi 