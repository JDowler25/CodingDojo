import React from 'react'

const DetailsPage = () => {
  return (
    <div>DetailsPage</div>
  )
}

export default DetailsPage