INSERT INTO dojos(name) VALUES('Dojo1');

SELECT * FROM dojos;