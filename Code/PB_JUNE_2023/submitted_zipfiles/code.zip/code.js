// likeCount value is set to 0 - what would this variable do?
var likeCount = 0;
// function is set to increase the value of likeCount - what would be the function of this code block?
function increaseLikes() {
    // likeCount is set to increase by 1 - what is this sort operation for?
    likeCount = likeCount + 1;
}
