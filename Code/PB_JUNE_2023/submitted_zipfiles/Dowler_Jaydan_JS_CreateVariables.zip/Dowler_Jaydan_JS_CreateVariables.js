// Create Variable for program to determine if a guest can ride the rollercoaster
var minimum_age = 10;
var minimum_height = 42;